import React, { useState } from "react";

function Customer() {
    const [customer, _setCustomer] = useState({ fName: "", lName: "" });
    const [customers, _setCustomers] = useState([]);
   
        const setCustomer = e => {
          _setCustomer(prevState => ({
                ...prevState,
                [e.target.name]: e.target.value
            }));
        };
        
        //const list = customers.map(x => <li>{x.fName}</li>);

  return (
    <div className="App">
      
         <input
            value={customer.fName}
            type="text"
            onChange={setCustomer}
            name="fName"
        />
        <input
            value={customer.lName}
            type="text"
            onChange={setCustomer}
            name="lName"
        /><br/>
          <input
            value="Add"
            type="button"
           
        />
      {customer.fName} {customer.lName} <br/>
     
    </div>
  );
}

export default Customer;
