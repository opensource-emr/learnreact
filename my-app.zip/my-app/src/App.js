import React, { useState } from "react";

function Customer() {
    const [customer, _setCustomer] = useState({ name: "", code: "" });
    const [customers, _setCustomers] = useState([]);
   
        const setCustomer = e => {
          _setCustomer(prevState => ({
                ...prevState,
                [e.target.name]: e.target.value
            }));
        };
        
        const setCustomers = e => {
          _setCustomers(prevState => (
                [...prevState, customer]
                ));
            _setCustomer(prevState => ({
              ...prevState,
               name: "", code: "" 
          }));
        };
        

  return (
    <div className="App">
      Name :- 
         <input
            value={customer.name}
            type="text"
            onChange={setCustomer}
            name="name"
        /><br></br>
    Code :- 
        <input
            value={customer.code}
            type="text"
            onChange={setCustomer}
            name="code"
        /><br/>
          <input
            value="Add"
            type="button"
            onClick={setCustomers}
        />
        <table>
          <tr>
            <td>name</td>
            <td>code</td>
          </tr>
        {customers.map(x => (
           <tr>
            <td>{x.name}</td>
            <td>{x.code}</td>
          </tr>
        ))}
      </table>
    </div>
    
  );
}

export default Customer;
